import{J as o,K as t,L as c,M as n}from"./framework.BdrDMkKq.js";const r={};function s(_,a){const e=t("RouterView");return c(),n(e)}const f=o(r,[["render",s]]);export{f as default};
