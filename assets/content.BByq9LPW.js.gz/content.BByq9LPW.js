import{d as e}from"./framework.BdrDMkKq.js";let n=[];function r(t){n.push(t),e(()=>{n=n.filter(o=>o!==t)})}const a=()=>n.forEach(t=>t()),s=a;export{r as o,s as r};
